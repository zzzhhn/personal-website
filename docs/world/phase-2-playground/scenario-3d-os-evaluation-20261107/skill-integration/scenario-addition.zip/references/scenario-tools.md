# Scenario tools: selective production and diagnosis

Pinned MIT upstream: [scenario-labs/skills](https://github.com/scenario-labs/skills/tree/e7e19d5f7cf14f3b84a16a261dfb6f77724bd637).
Source, copyright and file hashes are in ../vendor/scenario-blender/. Upstream modules remain unchanged.
This integration requires local Blender, not a Scenario account, network call or cloud generation.

## Use a tool for the observed problem

```python
import sys
sys.path.insert(0, "/Users/a22309/.codex/skills/blender-material-craft/scripts")
from scenario_tools import tool, audit_groups
HS, UV, M = tool("hard_surface"), tool("uv"), tool("materials")
```

Paths can be relocated with the skill. Inspect function signatures in the pinned script when needed.
Keep this skill's construction map, actual-view examples and runtime checks as the design authority.

| Problem / task | Useful tool | Inspect the result |
| --- | --- | --- |
| Machined edges, boolean cuts, broad flat panels | HS.hard_surface_stack, HS.stack_problems, HS.clamp_probe, HS.shading_audit | Separate broad design radii from fine edge breaks. Examine grazing highlights and actual silhouette; do not blindly add segments. |
| Stretching, tiny UV fragments, poor AO atlas | UV.uv_qa, UV.texel_density, UV.checker_review | Measure actual pixels per meter, distortion and padding. Shared tiling UV0 can overlap deliberately; unique AO/bake atlases require their own profile. |
| Normal/AO baking misses | UV.measure_projection, UV.bake_sanity, UV.map_problem_review | First test a small bake; fix geometry, source selection or cage when errors remain in the same place. |
| Plastic or noisy surfaces | M.audit_material, M.preview; build only necessary layers | Inspect roughness separately, mute one layer to assess its contribution, align wear with use and fabrication. Noise is not an improvement by itself. |
| Floating parts, reverse faces, coplanar faces | audit_groups or tool("audit").deliverable | Run per semantic assembly; inspect each error. Never weld a hinge or a group of independent props just to get a pass. |
| Silhouette and shading diagnosis | tool("review").review | Useful clay/matcap/wire/culling views complement the unchanged player-view camera. An audit sheet does not replace an in-game comparison. |
| glTF inspection and export checks | tool("export").glb_summary, export, round_trip | Keep project-specific axes, node names, extras, UV/wind attributes, materials and interaction datums. Plain glTF preset before optional extensions. |

## Adaptation boundaries

- A static body and an opening door/lid may be separate audit groups. Record every intended part; check the hinge, swept volume and contact across groups separately. Do not hide a real failure by making every mesh its own group.
- deliverable uses sampled spatial checks and scale-derived tolerances; very large part counts can skip checks. Its pass means those diagnostics found no error, not exhaustive intersection or walkability proof.
- UV coverage, texture sizes, bake distance, bevel widths and triangle budgets are measured design choices. Upstream defaults are not global requirements for this browser world.
- Avoid double-counting the same relief in normals and displacement. Different-scale normal and displacement detail can coexist; do not impose a blanket ban.
- Keep glTF AO separate from base color unless the established target specifically requires otherwise. Avoid baking dramatic lighting into a material used under changing weather/daylight.
- bx_export.compare sorts dimensions and checks map categories. It does not prove orientation, placement, texture-content equality, animation quality or shader equivalence. Retain our exact roots/anchors, material extensions and actual runtime checks.
- Its web preset expects Meshopt/WebP support. Do not replace an established Draco loader/compression route without checking the actual consumer. lods is for static meshes, and neither lods nor collision understands our gameplay routes.
- Existing per-scene batching, environment cache, pause/culling policy and ownership of shared textures remain in force. No additional full-scene realtime lighting or framebuffer effects merely to flatter a candidate.
- Texel density and a clean material audit do not detect screen-space moire. Inspect repeating cloth/grain at ordinary viewing distance and grazing angles in the actual renderer. Confirm mipmaps and minification filtering, then compare a hardware-bounded anisotropy change before reducing relief. If cached textures are borrowed, clone/cache only the required wrappers, share image sources and dispose only owned wrappers. Record both the original and corrected runtime view; don't silently credit an integration repair to the first authored asset.
- Upstream targets Blender 5.2.1. The local compatibility report records only the calls actually tested on 5.1.2. Read installed API/RNA before other calls. A cloud skill or GUI bridge is not needed to resolve headless work.
- Rendering, UV packing and material helpers can change selection/settings or work on objects. Use a saved task-owned native copy, not the user's open unsaved scene.

## Independent pilot

Give the successor the ordinary asset task, real baseline, approved visual examples and this skill. Let it choose the construction and applicable tools. Preserve its first complete source/GLB hashes before coordinator edits.

Compare the first result in normal player view, close construction view and relevant difficult light, using fixed camera, exposure, DPR and settled scene state. Record correctness, visible improvement and cost separately. If the coordinator repairs it, distinguish author result from integrated result. Do not claim that one successful pilot proves a causal gain over the old skill or parity between models without a controlled comparator.


"""Load the pinned Scenario Blender tools without cloud dependencies.

Use inside Blender. Tools operate on the supplied objects: run mutations on a
saved asset copy. Optional GUI brush helpers remain upstream-only.
"""
from pathlib import Path
import importlib
import sys

ROOT = Path(__file__).resolve().parents[1] / "vendor" / "scenario-blender"
MODULES = {
    "audit": ("scenario-blender-expert", "bx_audit"),
    "review": ("scenario-blender-expert", "bx_review"),
    "hard_surface": ("scenario-blender-hard-surface", "bx_hardsurface"),
    "materials": ("scenario-blender-texturing-shading", "bx_materials"),
    "uv": ("scenario-blender-uv-baking", "bx_uvbake"),
    "export": ("scenario-blender-export", "bx_export"),
}


def tool(name):
    """Return a pinned module; fail rather than reuse an unrelated installed copy."""
    family, module = MODULES[name]
    folder = ROOT / family / "scripts"
    path = str(folder)
    if path not in sys.path:
        sys.path.insert(0, path)
    existing = sys.modules.get(module)
    expected = (folder / (module + ".py")).resolve()
    if existing and Path(existing.__file__).resolve() != expected:
        raise RuntimeError(f"{module} is already loaded from {existing.__file__}; use a fresh Blender process")
    return importlib.import_module(module)


def audit_groups(groups, profile="game", **tolerances):
    """Check named semantic assemblies without welding independent moving parts.

    Example: {"cabinet": body_and_fixed_hardware, "lid": lid_and_handle}.
    Inter-group hinges, travel, clearance and support are NOT checked here.
    A plant cluster is not a single manufactured assembly.
    """
    if not groups or any(not objects for objects in groups.values()):
        raise ValueError("Declare non-empty semantic assemblies; omitted parts are not verified")
    audit = tool("audit")
    reports = {name: audit.deliverable(objects, profile=profile, **tolerances)
               for name, objects in groups.items()}
    return {
        "pass": all(report["pass"] for report in reports.values()),
        "groups": reports,
        "not_checked": ["inter-group contacts and articulation", "runtime collision and camera",
                        "visual quality", "runtime performance"],
    }


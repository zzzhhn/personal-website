"""Bounded compatibility test for the vendored entrypoints, not visual acceptance.
Run Blender factory startup with -- <output directory>.
"""
import json
from pathlib import Path
import sys
import bpy
sys.path.insert(0, str(Path(__file__).resolve().parent))
from scenario_tools import tool, audit_groups

out = Path(sys.argv[sys.argv.index("--") + 1])
out.mkdir(parents=True, exist_ok=True)
modules = {name: tool(name) for name in ("audit", "review", "hard_surface", "materials", "uv", "export")}
bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.ops.mesh.primitive_cube_add(size=1)
body = bpy.context.object
body.name = "Body"
body.location.z = 0.5
mat = bpy.data.materials.new("Paint")
mat.use_nodes = True
mat.node_tree.nodes.get("Principled BSDF").inputs["Base Color"].default_value = (0.25, 0.12, 0.05, 1)
body.data.materials.append(mat)
uv = modules["uv"].uv_qa(body, tex_res=256, analysis_res=128)
assert uv, "UV report absent"
issues = modules["materials"].audit_material(mat, body)
assert not any(level == "error" for level, _ in issues), issues
baseline = audit_groups({"body": [body]})
assert baseline["pass"], baseline
bpy.ops.mesh.primitive_cube_add(size=0.1, location=(0.8, 0, 0.5))
handle = bpy.context.object
handle.name = "DetachedHandle"
handle.data.materials.append(mat)
bad = audit_groups({"fixed": [body, handle]})
assert not bad["pass"], bad
declared = audit_groups({"body": [body], "independent": [handle]})
assert declared["pass"] and declared["not_checked"], declared
bpy.data.objects.remove(handle, do_unlink=True)
hs = modules["hard_surface"]
hs.hard_surface_stack(body, micro_width=0.008, micro_segments=2)
stack = hs.stack_problems(body)
assert not stack, stack
report = hs.shading_audit(body)
bpy.ops.object.select_all(action="DESELECT")
body.select_set(True)
bpy.context.view_layer.objects.active = body
glb = out / "smoke.glb"
bpy.ops.export_scene.gltf(filepath=str(glb), export_format="GLB", use_selection=True)
summary = modules["export"].glb_summary(str(glb))
result = {"blender": bpy.app.version_string, "imports": list(modules), "uv_fields": list(uv),
          "material_issues": issues, "body_audit": baseline, "detached_audit": bad,
          "separate_groups": declared, "stack_problems": stack, "shading_fields": list(report),
          "glb": summary, "not_tested": ["full tool suites", "render helpers", "baking", "visual uplift"]}
(out / "compatibility.json").write_text(json.dumps(result, indent=2, default=str) + "\n")
print("SCENARIO_COMPATIBILITY_OK", bpy.app.version_string, flush=True)

